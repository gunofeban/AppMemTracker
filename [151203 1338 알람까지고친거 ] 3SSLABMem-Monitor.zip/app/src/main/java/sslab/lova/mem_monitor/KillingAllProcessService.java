package sslab.lova.mem_monitor;

import android.app.ActivityManager;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Debug;
import android.os.Environment;
import android.os.IBinder;
import android.os.Process;
import android.provider.Settings;
import android.util.Log;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

import jxl.Workbook;
import jxl.format.Colour;
import jxl.write.WritableCellFormat;
import jxl.write.WritableSheet;
import jxl.write.WritableWorkbook;

/**
 * Created by JEFF on 2015-11-17.
 */
public class KillingAllProcessService extends Service {

    private ActivityManager activityManager;
    private long totalMemory;
    private long availableMegs;
    private String userSpace = "";
    private String kernelSpace = "";
    private int systemApp = 0, tpApp = 0, downloadApp = 0, installedAppNum = 0;
    private int SDK;
    private String ProductModel;
    private String buildVersion;
    private String kernelVersion;
    private int processApplicationMemory = 0;
    private Context mContext;
    Map<String, AppInfoClass> befServiceXmlList = new TreeMap<String, AppInfoClass>();
    Map<String, AppInfoClass> befProcessXmlList = new TreeMap<String, AppInfoClass>();

    String[] befServiceKeys;
    String[] befProcessKeys;

    List<String> tpAppList = new ArrayList<String>();
    List<String> downAppList = new ArrayList<String>();

    Map<String, Integer> killMapList = new TreeMap<String, Integer>();
    String[] killMapKey;

    ArrayList<String> currentProcessList;

    boolean isAlarm= false;
    String bootTime;

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("LOTTE", "KillingAppProcessService onStartCommand");

        activityManager = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
        mContext = this;

        repeatSettingAlarm();

        currentProcessList = convertRunningAppProcessToList(activityManager.getRunningAppProcesses());
        Intent i = new Intent(mContext, TopViewService.class);
        i.putExtra("isKillingServiceCall", true);
        i.putExtra("currentProcessList", currentProcessList);

        startKill();

        startService(i);

        if(intent != null){
            isAlarm = intent.getBooleanExtra("repeateAlarm",false);
        }

        if(!isAlarm){
            Log.d("LOTTE","메모리정보 메일 보낸다");
            bootTime = intent.getStringExtra("BootTime");
            getExcelFile();

            Thread thread = new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        Util.sendMail("Data.xls");
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                }
            });
            thread.start();
        }

        stopSelf();

        return super.onStartCommand(intent, flags, startId);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        Log.d("LOTTE","killingAllProcessService onDestory");
    }

    public void repeatSettingAlarm(){

        AlarmManager alarm = (AlarmManager)this.getSystemService(Context.ALARM_SERVICE);
        Intent intent = new Intent(mContext,KillingAllProcessService.class);
        intent.putExtra("repeateAlarm",true);
        PendingIntent pintent = PendingIntent.getService(this, 0, intent, 0);
        alarm.set(AlarmManager.RTC, System.currentTimeMillis() + 7200000, pintent);

        //300000 5분
        //3600000 1시간
        //
        //21600000 6시간

        Intent intent2 = new Intent(mContext,AlarmService.class);
        PendingIntent pintent2 = PendingIntent.getService(this, 0, intent2, 0);
        alarm.set(AlarmManager.RTC, System.currentTimeMillis() + 7200000, pintent2);
    }
    public ArrayList<String> convertRunningAppProcessToList(List<ActivityManager.RunningAppProcessInfo> rl) {

        ArrayList<String> list = new ArrayList<String>();

        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : rl) {
            if (runningAppProcessInfo.pid != android.os.Process.myPid()) {
                String str = "";
                try {
                    FileInputStream fis = new FileInputStream("/proc/" + runningAppProcessInfo.pid + "/oom_adj");
                    BufferedReader bufferedReader = new BufferedReader((new InputStreamReader(fis)));
                    str = bufferedReader.readLine();
                    double oom_adj = Double.parseDouble(str);

                    if (SDK >= 20) {
                        if (oom_adj > 4) {
                            list.add(runningAppProcessInfo.processName);
                        }

                        /**
                         * SDK 20 이하에서의 서비스, 프로세스분류
                         */
                    } else {
                        if (oom_adj > 3 ){
                            list.add(runningAppProcessInfo.processName);
                        }
                    }


                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } /// process  (Background process)

        return list;
    }

    public void startKill() {
        Log.d("LOTTE", "start kill 호출 ");


        final ActivityManager.MemoryInfo memoryInfo = new ActivityManager.MemoryInfo();

        final ArrayList<String> serviceApplicationInfo = new ArrayList<String>();

        Debug.MemoryInfo mMemoryInfo = new Debug.MemoryInfo();
        activityManager.getMemoryInfo(memoryInfo);
        availableMegs = memoryInfo.availMem / 1048576L;
        totalMemory = memoryInfo.totalMem / 1048576L;

        try {
            String str = "";
            FileInputStream fis = new FileInputStream("/proc/meminfo");
            BufferedReader bufferedReader = new BufferedReader((new InputStreamReader(fis)));
            while ((str = bufferedReader.readLine()) != null) {
                if (str.indexOf("HighTotal") != -1) {
                    userSpace = str;
                }
                if (str.indexOf("LowTotal") != -1) {
                    kernelSpace = str;
                }

            }
        } catch (Exception e) {
            e.printStackTrace();
        }


        //##############################################################################################################
        List<PackageInfo> packageInfos = getPackageManager().getInstalledPackages(PackageManager.GET_META_DATA);
        Drawable icon;
        for (PackageInfo packageInfo : packageInfos) {
            try {
                if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) {
                    if ((packageInfo.applicationInfo.flags & ApplicationInfo.FLAG_UPDATED_SYSTEM_APP) != 0) {
                        tpAppList.add(
                                (String) getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(packageInfo.applicationInfo.packageName, PackageManager.GET_UNINSTALLED_PACKAGES)));
                        tpApp++;
                    } else {
                        systemApp++;
                        serviceApplicationInfo.add(packageInfo.packageName);
                    }
                } else {
                    downloadApp++;
                    downAppList.add(
                            (String) getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(packageInfo.applicationInfo.packageName, PackageManager.GET_UNINSTALLED_PACKAGES)));
                }
            } catch (Exception e) {

            }
        }
        installedAppNum = downloadApp + tpApp;

        SDK = Build.VERSION.SDK_INT;
        ProductModel = Build.BRAND + " / " + Build.MODEL;
        buildVersion = Build.VERSION.RELEASE;
        kernelVersion = System.getProperty("os.version");

        final List<ActivityManager.RunningServiceInfo> rs = activityManager.getRunningServices(200);
        final List<ActivityManager.RunningAppProcessInfo> ps = activityManager.getRunningAppProcesses();

        for (ActivityManager.RunningAppProcessInfo runningAppProcessInfo : ps) {
            if (runningAppProcessInfo.pid != android.os.Process.myPid()) {
                String str = "";
                try {
                    FileInputStream fis = new FileInputStream("/proc/" + runningAppProcessInfo.pid + "/oom_adj");
                    BufferedReader bufferedReader = new BufferedReader((new InputStreamReader(fis)));
                    str = bufferedReader.readLine();
                    double oom_adj = Double.parseDouble(str);
                    int meminfo[] = {runningAppProcessInfo.pid, 0};
                    Debug.MemoryInfo debugMeminfo[] = activityManager.getProcessMemoryInfo(meminfo);
                    for (android.os.Debug.MemoryInfo pidMemoryInfo : debugMeminfo) {
                        if (pidMemoryInfo.getTotalPss() != 0) {
                            Drawable mIcon;
                            String psLabel;
                            if (SDK >= 20) {
                                if (oom_adj >= 0 && oom_adj < 8) {
                                    try {
                                        psLabel = (String) getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(runningAppProcessInfo.pkgList[0], PackageManager.GET_UNINSTALLED_PACKAGES));
                                        mIcon = getPackageManager().getApplicationIcon(runningAppProcessInfo.pkgList[0]);
                                    } catch (Exception e) {
                                        psLabel = "NameNotFound";
                                        mIcon = getResources().getDrawable(R.mipmap.ic_launcher);
                                    }
                                    AppInfoClass mAppInfoClass = new AppInfoClass(mIcon, runningAppProcessInfo.pid, psLabel, 0, pidMemoryInfo.getTotalPss(), runningAppProcessInfo.importance, oom_adj);
                                    befServiceXmlList.put(Integer.toString(runningAppProcessInfo.pid), mAppInfoClass);

                                } else if (oom_adj >= 8) {
                                    try {
                                        psLabel = (String) getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(runningAppProcessInfo.pkgList[0], PackageManager.GET_UNINSTALLED_PACKAGES));
                                        mIcon = getPackageManager().getApplicationIcon(runningAppProcessInfo.pkgList[0]);
                                    } catch (Exception e) {
                                        psLabel = "NameNotFound";
                                        mIcon = getResources().getDrawable(R.mipmap.ic_launcher);
                                    }
                                    AppInfoClass mAppInfoClass = new AppInfoClass(mIcon, runningAppProcessInfo.pid, psLabel, 0, pidMemoryInfo.getTotalPss(), runningAppProcessInfo.importance, oom_adj);
                                    befProcessXmlList.put(Integer.toString(runningAppProcessInfo.pid), mAppInfoClass);
                                }
                                killMapList.put(runningAppProcessInfo.processName, runningAppProcessInfo.pid);
                                /**
                                 * SDK 20 이하에서의 서비스, 프로세스분류
                                 */
                            } else {
                                if (oom_adj >= 0 && oom_adj < 9) {
                                    try {
                                        psLabel = (String) getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(runningAppProcessInfo.pkgList[0], PackageManager.GET_UNINSTALLED_PACKAGES));
                                        mIcon = getPackageManager().getApplicationIcon(runningAppProcessInfo.pkgList[0]);
                                    } catch (Exception e) {
                                        psLabel = "NameNotFound";
                                        mIcon = getResources().getDrawable(R.mipmap.ic_launcher);
                                    }
                                    AppInfoClass mAppInfoClass = new AppInfoClass(mIcon, runningAppProcessInfo.pid, psLabel, 0, pidMemoryInfo.getTotalPss(), runningAppProcessInfo.importance, oom_adj);
                                    befServiceXmlList.put(Integer.toString(runningAppProcessInfo.pid), mAppInfoClass);
                                }
                                if (oom_adj >= 9) {
                                    try {
                                        psLabel = (String) getPackageManager().getApplicationLabel(getPackageManager().getApplicationInfo(runningAppProcessInfo.pkgList[0], PackageManager.GET_UNINSTALLED_PACKAGES));
                                        mIcon = getPackageManager().getApplicationIcon(runningAppProcessInfo.pkgList[0]);
                                    } catch (Exception e) {
                                        psLabel = "NameNotFound";
                                        mIcon = getResources().getDrawable(R.mipmap.ic_launcher);
                                    }
                                    AppInfoClass mAppInfoClass = new AppInfoClass(mIcon, runningAppProcessInfo.pid, psLabel, 0, pidMemoryInfo.getTotalPss(), runningAppProcessInfo.importance, oom_adj);
                                    befProcessXmlList.put(Integer.toString(runningAppProcessInfo.pid), mAppInfoClass);
                                }
                                killMapList.put(runningAppProcessInfo.processName, runningAppProcessInfo.pid);
                            }
                        }
                    }
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        } /// process  (Background process)

        try {
            killMapKey = killMapList.keySet().toArray(new String[0]);
            for (int i = 0; i < killMapKey.length; i++) {
                Log.d("KILL", killMapList.get(killMapKey[i]) + " kill");
                android.os.Process.sendSignal(killMapList.get(killMapKey[i]), Process.SIGNAL_KILL);
                activityManager.killBackgroundProcesses(killMapKey[i]);
            }
        } catch (Exception e) {

        }

        befProcessKeys = befProcessXmlList.keySet().toArray(new String[0]);
        befServiceKeys = befServiceXmlList.keySet().toArray(new String[0]);

        Log.d("LOTTE", "startKill finish");
        //startingService();
    }

    void getExcelFile() {
        try {
            int row = 0, column = 0;

            File xmlFile = new File(Environment.getExternalStorageDirectory() + "/SSLAB/Data.xls");
            xmlFile.getParentFile().mkdirs();
            WritableWorkbook workbook = Workbook.createWorkbook(new File(Environment.getExternalStorageDirectory() + "/Data.xls"));

            WritableSheet sheet1 = workbook.createSheet("디바이스 메모리 정보", 0);

            jxl.write.WritableCellFormat format = new WritableCellFormat();
            jxl.write.WritableCellFormat classifyFormat = new WritableCellFormat();

            classifyFormat.setBackground(Colour.BLUE_GREY);

            jxl.write.Label label = null;

            label = new jxl.write.Label(0, row, "안드로이드 버전", classifyFormat);
            sheet1.addCell(label);
            label = new jxl.write.Label(1, row, "커널 버전", classifyFormat);
            sheet1.addCell(label);
            label = new jxl.write.Label(2, row, "디바이스 이름", classifyFormat);
            sheet1.addCell(label);
            label = new jxl.write.Label(3, row, "디바이스 전체 메모리", classifyFormat);
            sheet1.addCell(label);
            label = new jxl.write.Label(4, row, "커널 영역", classifyFormat);
            sheet1.addCell(label);
            label = new jxl.write.Label(5, row, "유저 영역", classifyFormat);
            sheet1.addCell(label);
            label = new jxl.write.Label(6, row, "디바이스 ID", classifyFormat);
            sheet1.addCell(label);
            label = new jxl.write.Label(7, row, "부팅시간", classifyFormat);
            sheet1.addCell(label);

            row++;
            label = new jxl.write.Label(0, row, buildVersion, format);
            sheet1.addCell(label);
            label = new jxl.write.Label(1, row, kernelVersion, format);
            sheet1.addCell(label);
            label = new jxl.write.Label(2, row, ProductModel, format);
            sheet1.addCell(label);
            label = new jxl.write.Label(3, row, "" + totalMemory + "MB", format);
            sheet1.addCell(label);
            label = new jxl.write.Label(4, row, kernelSpace, format);
            sheet1.addCell(label);
            label = new jxl.write.Label(5, row, userSpace, format);
            sheet1.addCell(label);
            label = new jxl.write.Label(6, row, Settings.Secure.getString(mContext.getContentResolver(), Settings.Secure.ANDROID_ID), format);
            sheet1.addCell(label);
            label = new jxl.write.Label(7, row, bootTime , format);
            sheet1.addCell(label);
            // 버전, 커널, 디바이스이름 입력

            row++;
            row++;

            // 빌트인 설치된 어플리케이션 목록
            label = new jxl.write.Label(0, row, "빌트인 설치된 어플리케이션 목록", classifyFormat);
            sheet1.addCell(label);
            row++;
            row = mAppListToExcel(tpAppList, sheet1, format, row);

            label = new jxl.write.Label(0, row, "다운로드 어플리케이션 목록", classifyFormat);
            sheet1.addCell(label);
            row++;
            row = mAppListToExcel(downAppList, sheet1, format, row);
            label = new jxl.write.Label(0, row, "서비스 목록", classifyFormat);
            sheet1.addCell(label);
            row++;
            row = mServProcListToXml(befServiceXmlList, sheet1, format, row, befServiceKeys);


            label = new jxl.write.Label(0, row, "캐시드 목록", classifyFormat);
            sheet1.addCell(label);
            row++;
            row = mCachedListToXml(befProcessXmlList, sheet1, format, row);

            // 빌트인 목록 추가
            workbook.write();
            workbook.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    int mAppListToExcel(List<String> appList, WritableSheet sheet, WritableCellFormat cell, int row) {
        jxl.write.Label label = null;
        try {
            label = new jxl.write.Label(0, row, "이름", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(1, row, "카테고리", cell);
            sheet.addCell(label);
            row++;
            for (int i = 0; i < appList.size(); i++) {

                label = new jxl.write.Label(0, row, appList.get(i), cell);
                sheet.addCell(label);
                row++;
            }

            label = new jxl.write.Label(0, row, "총합", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(1, row, Integer.toString(appList.size()) + "개", cell);
            sheet.addCell(label);
            row++;
        } catch (Exception e) {

        }
        row++;
        return row++;
    }

    int mCachedListToXml(Map<String, AppInfoClass> procList, WritableSheet sheet, WritableCellFormat cell, int row) {
        jxl.write.Label label = null;
        int resultMemory = 0;
        try {
            label = new jxl.write.Label(0, row, "이름", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(1, row, "사이즈", cell);
            sheet.addCell(label);
            row++;
            String[] keySets = procList.keySet().toArray(new String[0]);
            for (int i = 0; i < keySets.length; i++) {
                String name = keySets[i];
                AppInfoClass aif = procList.get(name);
                int memSize = aif.getMemory();
                label = new jxl.write.Label(0, row, aif.getName(), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(1, row, Integer.toString(memSize), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(2, row, Util.importanceToString(aif.importance), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(3, row, Double.toString(aif.oom_adj), cell);
                sheet.addCell(label);
                row++;
                resultMemory += memSize;
            }
            label = new jxl.write.Label(0, row, "총 메모리", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(1, row, Integer.toString(resultMemory / 1024) + "MB", cell);
            sheet.addCell(label);
            row++;
            row++;

        } catch (Exception e) {

        }
        return row++;
    }

    int mServListToXml(Map<String, AppInfoClass> procList, WritableSheet sheet, WritableCellFormat cell, int row) {
        final jxl.write.WritableCellFormat subFormat = new WritableCellFormat();
        jxl.write.Label label = null;
        int resultMemory = 0;
        try {
            subFormat.setBackground(Colour.BRIGHT_GREEN);
            AppInfoClass mTempClass;
            label = new jxl.write.Label(0, row, "이름", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(1, row, "사이즈", cell);
            sheet.addCell(label);
            row++;
            List<AppInfoClass> AServiceList = new ArrayList<AppInfoClass>();
            List<AppInfoClass> BSerciveList = new ArrayList<AppInfoClass>();

            String[] keySets = procList.keySet().toArray(new String[0]);
            for (int i = 0; i < keySets.length; i++) {
                String name = keySets[i];
                int memSize;
                AppInfoClass aif = procList.get(name);
                if (aif.oom_adj == 4.0) {
                    AServiceList.add(aif);
                } else if (aif.oom_adj == 7.0) {
                    BSerciveList.add(aif);
                } else {

                }
            }
            label = new jxl.write.Label(0, row, "A Service", subFormat);
            sheet.addCell(label);
            row++;
            for (int j = 0; j < AServiceList.size(); j++) {
                mTempClass = AServiceList.get(j);
                label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                sheet.addCell(label);
                row++;
                resultMemory += mTempClass.cur_memory;

            }
            label = new jxl.write.Label(0, row, "B Service", subFormat);
            sheet.addCell(label);
            row++;
            for (int j = 0; j < BSerciveList.size(); j++) {
                mTempClass = BSerciveList.get(j);
                label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                sheet.addCell(label);
                label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                sheet.addCell(label);
                row++;
                resultMemory += mTempClass.cur_memory;
            }

            label = new jxl.write.Label(0, row, "총 메모리", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(1, row, Integer.toString(resultMemory / 1024) + "MB", cell);
            sheet.addCell(label);
            row++;
            row++;
        } catch (Exception e) {

        }
        return row++;
    }

    int mServProcListToXml(Map<String, AppInfoClass> procList, WritableSheet sheet, WritableCellFormat cell, int row, String[] keySets) {
        final jxl.write.WritableCellFormat subFormat = new WritableCellFormat();

        jxl.write.Label label = null;
        int resultMemory = 0;
        AppInfoClass mTempClass;
        try {
            subFormat.setBackground(Colour.BRIGHT_GREEN);
            label = new jxl.write.Label(0, row, "이름", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(1, row, "사이즈", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(2, row, "Importance", cell);
            sheet.addCell(label);
            label = new jxl.write.Label(3, row, "OOM_ADJ", cell);
            sheet.addCell(label);
            row++;

            if (SDK < 21) {
                List<AppInfoClass> foreGroundList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> visibleList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> perceptableList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> HomeList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> AServiceList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> BSerciveList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> previousList = new ArrayList<AppInfoClass>();
                for (int i = 0; i < keySets.length; i++) {
                    String name = keySets[i];
                    int memSize;
                    AppInfoClass aif = procList.get(name);
                    if (aif.oom_adj == 0.0) {
                        foreGroundList.add(aif);
                    } else if (aif.oom_adj == 1.0) {
                        visibleList.add(aif);
                    } else if (aif.oom_adj == 2.0) {
                        perceptableList.add(aif);
                    } else if (aif.oom_adj == 5.0) {
                        AServiceList.add(aif);
                    } else if (aif.oom_adj == 6.0) {
                        HomeList.add(aif);
                    } else if (aif.oom_adj == 7.0) {
                        previousList.add(aif);
                    } else if (aif.oom_adj == 8.0) {
                        BSerciveList.add(aif);
                    } else {

                    }
                }
                label = new jxl.write.Label(0, row, "FOREGROUND", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < foreGroundList.size(); j++) {
                    mTempClass = foreGroundList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }
                label = new jxl.write.Label(0, row, "VISIBLE", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < visibleList.size(); j++) {
                    mTempClass = visibleList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;
                }
                label = new jxl.write.Label(0, row, "PERCELTABLE", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < perceptableList.size(); j++) {
                    mTempClass = perceptableList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;
                }
                label = new jxl.write.Label(0, row, "HOME", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < HomeList.size(); j++) {
                    mTempClass = HomeList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }
                label = new jxl.write.Label(0, row, "PREVIOUS", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < previousList.size(); j++) {
                    mTempClass = previousList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }
                label = new jxl.write.Label(0, row, "A Service", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < AServiceList.size(); j++) {
                    mTempClass = AServiceList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }
                label = new jxl.write.Label(0, row, "B Service", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < BSerciveList.size(); j++) {
                    mTempClass = BSerciveList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }

                label = new jxl.write.Label(0, row, "총 메모리", cell);
                sheet.addCell(label);
                label = new jxl.write.Label(1, row, Integer.toString(resultMemory / 1024) + "MB", cell);
                sheet.addCell(label);
                row++;
                row++;


            } else {
                List<AppInfoClass> visibleList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> perceptableList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> HomeList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> AServiceList = new ArrayList<AppInfoClass>();
                List<AppInfoClass> BSerciveList = new ArrayList<AppInfoClass>();
                for (int i = 0; i < keySets.length; i++) {
                    String name = keySets[i];
                    int memSize;
                    AppInfoClass aif = procList.get(name);
                    if (aif.oom_adj == 0.0) {
                        visibleList.add(aif);
                    } else if (aif.oom_adj == 1.0) {
                        perceptableList.add(aif);
                    } else if (aif.oom_adj == 4.0) {
                        AServiceList.add(aif);
                    } else if (aif.oom_adj == 5.0) {
                        HomeList.add(aif);
                    } else if (aif.oom_adj == 7.0) {
                        BSerciveList.add(aif);
                    } else {

                    }
                }
                label = new jxl.write.Label(0, row, "VISIBLE", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < visibleList.size(); j++) {
                    mTempClass = visibleList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;
                }
                label = new jxl.write.Label(0, row, "PERCELTABLE", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < perceptableList.size(); j++) {
                    mTempClass = perceptableList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;
                }
                label = new jxl.write.Label(0, row, "HOME", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < HomeList.size(); j++) {
                    mTempClass = HomeList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }
                label = new jxl.write.Label(0, row, "A Service", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < AServiceList.size(); j++) {
                    mTempClass = AServiceList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }
                label = new jxl.write.Label(0, row, "B Service", subFormat);
                sheet.addCell(label);
                row++;
                for (int j = 0; j < BSerciveList.size(); j++) {
                    mTempClass = BSerciveList.get(j);
                    label = new jxl.write.Label(0, row, mTempClass.getName(), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(1, row, Integer.toString(mTempClass.cur_memory), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(2, row, Util.importanceToString(mTempClass.importance), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(3, row, Double.toString(mTempClass.oom_adj), cell);
                    sheet.addCell(label);
                    label = new jxl.write.Label(4, row, Double.toString(mTempClass.pid), cell);
                    sheet.addCell(label);
                    row++;
                    resultMemory += mTempClass.cur_memory;

                }

                label = new jxl.write.Label(0, row, "총 메모리", cell);
                sheet.addCell(label);
                label = new jxl.write.Label(1, row, Integer.toString(resultMemory / 1024) + "MB", cell);
                sheet.addCell(label);
                row++;
                row++;


            }

        } catch (Exception e) {

        }
        return row++;
    }
}
